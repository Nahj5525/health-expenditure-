#!/usr/bin/env python3
"""Independent supplementary analyses for Frontiers health-expenditure revision.

Requires supplied data in /mnt/data. The upstream pre-filter merge is unavailable, but the original core
program has now been supplied and is stored under ../core/src/. All cross-validation choices
are explicit and appendix values are generated from the retained supplied files.
"""
from __future__ import annotations
import json
from pathlib import Path
from itertools import product
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_cluster_2groups
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Lasso, ElasticNet, Ridge, LinearRegression
from sklearn.svm import SVR
from sklearn.ensemble import GradientBoostingRegressor

ROOT=Path(__file__).resolve().parent; OUT=ROOT/'frontiers_new_results'; OUT.mkdir(exist_ok=True)
RNG=np.random.default_rng(20261031)
B=5000

def rmse(y,p):return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(p))**2)))
def skill(y,p,base):return float(100*(1-np.mean((np.asarray(y)-np.asarray(p))**2)/np.mean((np.asarray(y)-np.asarray(base))**2)))
def model(a=.01):return make_pipeline(StandardScaler(),Lasso(alpha=a,max_iter=150000,random_state=0))
def save_csv(df,name):df.to_csv(OUT/name,index=False,encoding='utf-8-sig')
def bci(x):return list(map(float,np.quantile(x,[.025,.975])))
def paired_bootstrap(df, base='persistence', challenger='lasso', reps=B):
    tmp=df.reset_index(drop=True).copy()
    groups_country={k:dfx.index.to_numpy() for k,dfx in tmp.groupby('Country_EN')}
    groups_year={k:dfx.index.to_numpy() for k,dfx in tmp.groupby('Year')}
    y=tmp['actual'].to_numpy();p=tmp[challenger].to_numpy();q=tmp[base].to_numpy()
    out={'N':len(tmp), 'countries':len(groups_country),'years':len(groups_year),
         'RMSE_challenger':rmse(y,p),'RMSE_persistence':rmse(y,q),
         'delta_RMSE':rmse(y,p)-rmse(y,q),'skill_pct':skill(y,p,q),
         'mean_loss_gain':float(np.mean((y-q)**2-(y-p)**2))}
    for typ,clusters in [('country',groups_country),('year',groups_year)]:
        keys=list(clusters);k=len(keys);vals=[]
        for _ in range(reps):
            ids=np.concatenate([clusters[j] for j in RNG.choice(keys,size=k,replace=True)])
            pr=rmse(y[ids],p[ids]);qr=rmse(y[ids],q[ids]);s=100*(1-(pr/qr)**2) if qr>0 else np.nan
            vals.append((pr-qr,s))
        vals=np.asarray(vals)
        out[f'{typ}_95ci_delta_RMSE']=bci(vals[:,0]);out[f'{typ}_95ci_skill_pct']=bci(vals[:,1])
        out[f'{typ}_P_delta_ge_0']=float(np.mean(vals[:,0]>=0))
    return out

# 1. Core forecasts, 16-candidate transparent additional sensitivity
core=pd.read_csv(ROOT/'analysis_dataset_one_year_ahead(3).csv')
feats=[c for c in core if c.startswith('L1_')]
roster=[]
for a in [.001,.003,.01,.03,.1]:roster.append((f'LASSO_alpha_{a}',lambda a=a:model(a)))
for a in [.003,.01,.03]:roster.append((f'ElasticNet_alpha_{a}_l1ratio_0.5',lambda a=a:make_pipeline(StandardScaler(),ElasticNet(alpha=a,l1_ratio=.5,max_iter=150000,random_state=0))))
for a in [.1,1.,10.]:roster.append((f'Ridge_alpha_{a}',lambda a=a:make_pipeline(StandardScaler(),Ridge(alpha=a))))
roster += [ ('Pooled_AR1', lambda:LinearRegression()),
           ('AR_only_LASSO_alpha_0.01',lambda:model(.01)),
           ('Full_OLS',lambda:make_pipeline(StandardScaler(),LinearRegression())),
           ('SVR_C1_epsilon0.1',lambda:make_pipeline(StandardScaler(),SVR(C=1,epsilon=.1))),
           ('GBR_100_depth2',lambda:GradientBoostingRegressor(n_estimators=100,max_depth=2,random_state=0))]
assert len(roster)==16
pd.DataFrame([{'index':i+1,'candidate':k,'hyperparameters':'fixed before test (sensitivity candidate, not claimed as original pre-specified roster)'} for i,(k,_) in enumerate(roster)]).to_csv(OUT/'candidate_roster_16.csv',index=False)
core_rows=[]
for year in range(2013,2021):
    tr=core[core.Year<year];te=core[core.Year==year]
    out=te[['Country_EN','Year','HEALTH_GDP','L1_HEALTH_GDP']].rename(columns={'HEALTH_GDP':'actual','L1_HEALTH_GDP':'persistence'}).copy()
    for key,factory in roster:
        mod=factory()
        ps=['L1_HEALTH_GDP'] if key in ('Pooled_AR1','AR_only_LASSO_alpha_0.01') else feats
        mod.fit(tr[ps],tr.HEALTH_GDP)
        out[key]=mod.predict(te[ps])
    out['lasso']=out['LASSO_alpha_0.01']
    core_rows.append(out)
co=pd.concat(core_rows,ignore_index=True).sort_values(['Year','Country_EN']).reset_index(drop=True)
save_csv(co,'core_predictions_16_candidates.csv')
assert len(co)==307
core_perf={'N':len(co),'countries':co.Country_EN.nunique(),'RMSE_LASSO':rmse(co.actual,co.lasso),
           'RMSE_persistence':rmse(co.actual,co.persistence),'MSE_skill_pct':skill(co.actual,co.lasso,co.persistence)}
core_unc=paired_bootstrap(co)
# two-way loss differential, Cameron-Gelbach-Miller inclusion-exclusion; G-1 adjustments via statsmodels
D=((co.actual-co.persistence)**2-(co.actual-co.lasso)**2).to_numpy()
fit=sm.OLS(D,np.ones((len(D),1))).fit()
cs=co.Country_EN.astype('category').cat.codes.to_numpy()
cv,cv_country,cv_year=cov_cluster_2groups(fit,cs,co.Year.to_numpy(),use_correction=True)
se=float(np.sqrt(cv[0,0]));tstat=float(fit.params[0]/se)
p_2way=float(2*stats.t.sf(abs(tstat),df=co.Year.nunique()-1))
# Whole-year sign-flip randomisation sensitivity: exact 2^8 patterns, sign-symmetry assumption
vals=np.array([D[co.Year.to_numpy()==yr].sum() for yr in sorted(co.Year.unique())])
s_obs=abs(D.mean());s_null=[]
for signs in product([-1,1],repeat=len(vals)):
    s_null.append(abs(np.dot(np.array(signs),vals)/len(D)))
sign_p=float(np.mean(np.asarray(s_null)>=s_obs-1e-12))
core_infer={'loss_gain_mean':float(D.mean()),'variance_estimator':'CGM two-way country/year cluster sandwich; country+year-intersection finite-sample corrections (statsmodels use_correction=True)','variance_two_way':float(cv[0,0]),'variance_country':float(cv_country[0,0]),'variance_year':float(cv_year[0,0]),'SE_two_way':se,'t_stat':tstat,'reference_distribution':'Student t with 7 df=min(40,8)-1','p_two_sided':p_2way,'year_signflip_exact_p_two_sided':sign_p,'signflip_clusters':8,'signflip_patterns':len(s_null),'year_signflip_assumption':'exchangeable independent sign-symmetric annual aggregate loss differentials; not a formal serial-correlation correction'}
# White-style 16-model performance screen, year block centred (common year shocks) and country block centred
candidate_names=[k for k,_ in roster]
dmat=np.column_stack([(co.actual-co.persistence)**2-(co.actual-co[k])**2 for k in candidate_names])
observed_each=dmat.mean(axis=0);winner=int(np.argmax(observed_each));T=float(observed_each.max())
# whole year resampling; all countries in a year sampled together; centred candidate annual average, equal observation weighting
# ensure test statistic uses one pooled obs/row and recomputes mean using bootstrap drawn rows
ids_year={y:np.where(co.Year.to_numpy()==y)[0] for y in sorted(co.Year.unique())}
ids_country={c:np.where(co.Country_EN.to_numpy()==c)[0] for c in sorted(co.Country_EN.unique())}
centered=dmat-observed_each
rc={}
for method,blocks in [('year',ids_year),('country',ids_country)]:
  keys=list(blocks);nt=len(keys);stat=[]
  for _ in range(B):
    ids=np.concatenate([blocks[k] for k in RNG.choice(keys,size=nt,replace=True)])
    stat.append(float(centered[ids].mean(axis=0).max()))
  vals=np.asarray(stat);rc[f'{method}_bootstrap_p']=float((1+np.sum(vals>=T))/(B+1))
  rc[f'{method}_bootstrap_95pct_null']=float(np.percentile(vals,95))
rc.update({'observed_max_mean_squared_loss_gain':T,'winner':candidate_names[winner],'winner_RMSE':rmse(co.actual,co[candidate_names[winner]]),'candidate_count':16,'bootstrap_draws':B,'weighting':'pooled country-year forecasts, each evaluation row equal weight','null_recentering':'each candidate loss differential centred at its full evaluation sample mean','assumption':'exchangeable blocks for null distribution, year-block gives common-shock sensitivity but 8 years insufficient to establish serial stationarity','note':'this newly specified candidate set is NOT the original unavailable 16-model set, and its p-value does not independently validate the previously stated 0.5212'} )

# 2. Lagged expenditure inclusion sensitivity (log currency variables truly lagged; no contemporaneous reconstruction)
src=pd.read_csv(ROOT/'source_dataset_762_utf8(3).csv')
lag=src[['Country_EN','Year','HE_PC_USD','HE_PC_PPP']].copy();lag['Year']+=1;lag=lag.rename(columns={'HE_PC_USD':'L1_HE_PC_USD_LOG','HE_PC_PPP':'L1_HE_PC_PPP_LOG'})
aug=core.merge(lag,on=['Country_EN','Year'],how='left',validate='one_to_one');assert aug[['L1_HE_PC_USD_LOG','L1_HE_PC_PPP_LOG']].notna().all().all()
sensitivity_names={'Baseline_22_features':feats,
 'Plus_lagged_log_HE_per_capita_USD':feats+['L1_HE_PC_USD_LOG'],
 'Plus_lagged_log_HE_per_capita_PPP':feats+['L1_HE_PC_PPP_LOG'],
 'Plus_both_lagged_health_per_capita':feats+['L1_HE_PC_USD_LOG','L1_HE_PC_PPP_LOG']}
sens=[];sens_preds=[]
for yy in range(2013,2021):
 tr=aug[aug.Year<yy];te=aug[aug.Year==yy]
 out=te[['Country_EN','Year','HEALTH_GDP','L1_HEALTH_GDP']].rename(columns={'HEALTH_GDP':'actual','L1_HEALTH_GDP':'persistence'}).copy()
 for name,f in sensitivity_names.items():
  est=model(.01).fit(tr[f],tr.HEALTH_GDP);out[name]=est.predict(te[f]);
 sens_preds.append(out)
sp=pd.concat(sens_preds,ignore_index=True)
for name in sensitivity_names:
 sens.append({'specification':name,'N':len(sp),'RMSE':rmse(sp.actual,sp[name]),'MSE_skill_pct':skill(sp.actual,sp[name],sp.persistence),'delta_RMSE_vs_baseline':rmse(sp.actual,sp[name])-rmse(sp.actual,sp['Baseline_22_features'])})
save_csv(sp,'lagged_expenditure_sensitivity_predictions.csv');save_csv(pd.DataFrame(sens),'lagged_expenditure_sensitivity.csv')

# 3. Conventional MASE using origin-specific, within-country naive TRAINING histories
x=src[['Country_EN','Year','HEALTH_GDP']].copy(); pairs=[]
for cname,g in x.groupby('Country_EN'):
 g=g.sort_values('Year');prev=g.shift(1)
 for i,row in g.iterrows():
  if pd.notna(prev.loc[i,'Year']) and row.Year-prev.loc[i,'Year']==1:
   pairs.append((cname,int(row.Year),abs(row.HEALTH_GDP-prev.loc[i,'HEALTH_GDP'])))
naive=pd.DataFrame(pairs,columns=['Country_EN','Year','abs_naive_change'])
mased=[]
for r in co.itertuples(index=False):
 d=naive[(naive.Country_EN==r.Country_EN)&(naive.Year<r.Year)]
 den=float(d.abs_naive_change.mean()) if len(d) else np.nan
 mased.append({'Country_EN':r.Country_EN,'Year':r.Year,'denominator':den,
               'scaled_abs_LASSO':abs(r.actual-r.lasso)/den if den>0 else np.nan,
               'scaled_abs_persistence':abs(r.actual-r.persistence)/den if den>0 else np.nan})
mased=pd.DataFrame(mased)
save_csv(mased,'training_only_MASE_per_forecast.csv')
valid=mased.dropna()
bycountry=valid.groupby('Country_EN')[['scaled_abs_LASSO','scaled_abs_persistence']].mean()
mase_summary={'scaling':'mean naive consecutive 1-step absolute error within same country, restricted to actual observed years strictly before forecast target year','forecast_cases_valid':len(valid),'forecast_cases_missing_or_zero_denominator':len(mased)-len(valid),'macro_average_country_MASE_LASSO':float(bycountry.scaled_abs_LASSO.mean()),'macro_average_country_MASE_persistence':float(bycountry.scaled_abs_persistence.mean()),'micro_average_observation_MASE_LASSO':float(valid.scaled_abs_LASSO.mean()),'micro_average_observation_MASE_persistence':float(valid.scaled_abs_persistence.mean()),'countries_valid':len(bycountry)}

# 4. Horizon strict year-to-year coverage AND direct-forecast origin cutoffs
idx=set(zip(src.Country_EN,src.Year))
horizon=[];horizon_predictions=[]
for h in [1,2,3]:
 d=pd.read_csv(ROOT/f'analysis_dataset_horizon_{h}(2).csv')
 n0=len(d)
 include=np.array([all((row.Country_EN,int(row.Year)-j) in idx for j in range(h+1)) for row in d.itertuples(index=False)])
 d=d[include].copy();fs=[c for c in d if c.startswith(f'L{h}_')]
 rows=[]
 for yy in range(2013,2021):
  tr=d[d.Year<=yy-h];te=d[d.Year==yy]
  est=model(.01).fit(tr[fs],tr.HEALTH_GDP)
  sub=te[['Country_EN','Year','HEALTH_GDP',f'L{h}_HEALTH_GDP']].copy()
  sub=sub.rename(columns={'HEALTH_GDP':'actual',f'L{h}_HEALTH_GDP':'persistence'})
  sub['lasso']=est.predict(te[fs]);sub['horizon']=h;sub['last_eligible_training_target_year']=yy-h
  rows.append(sub)
 p=pd.concat(rows,ignore_index=True);horizon_predictions.append(p)
 horizon.append({'horizon_years':h,'n_full_lag_file':n0,'excluded_nonconsecutive_year_gap':n0-len(d),
                 'n_evaluation':len(p),'RMSE_LASSO':rmse(p.actual,p.lasso),'RMSE_persistence':rmse(p.actual,p.persistence),'MSE_skill_pct':skill(p.actual,p.lasso,p.persistence),
                 'protocol':'direct h-step, training target s <= target year t-h, all intermediate reference years observed, LASSO alpha fixed 0.01 for comparability; NOT a replication of any undocumented legacy horizon-specific tuning'})
save_csv(pd.DataFrame(horizon),'horizon_strict_origin_results.csv');save_csv(pd.concat(horizon_predictions,ignore_index=True),'horizon_strict_predictions.csv')

# 5. Restricted current-release ARX, re-estimated with pre-2013 validation only
extension=pd.read_csv(ROOT/'worldbank_latest_original_country_extension(2).csv')
post_models={'CHE_GDP':['L1_CHE_GDP','L1_PUBLIC_CHE','L1_OOP_CHE'], 'PUBLIC_GDP':['L1_PUBLIC_GDP','L1_OOP_CHE']}
post_names={'CHE_GDP':'CHE/GDP','PUBLIC_GDP':'Government/GDP'}
post_frames=[];alphas=[]
for targ,fx in post_models.items():
 d=extension.dropna(subset=[targ]+fx).copy();d=d[d.Consecutive.astype(bool)]
 checks=[]
 for a in [.001,.003,.01,.03,.1]:
  scores=[]
  for val_start,val_end in [(2007,2008),(2009,2010),(2011,2012)]:
   tr=d[d.Year<val_start];te=d[d.Year.between(val_start,val_end)]
   est=model(a).fit(tr[fx],tr[targ]);scores.extend((te[targ]-est.predict(te[fx]))**2)
  checks.append({'target':targ,'alpha':a,'pre2013_validation_MSE':float(np.mean(scores))})
 alp=min(checks,key=lambda r:r['pre2013_validation_MSE'])['alpha'];alphas.extend(checks)
 annual=[]
 for year in range(2013,2025):
  tr=d[d.Year<year];te=d[d.Year==year]
  mod=model(alp).fit(tr[fx],tr[targ]);ar=LinearRegression().fit(tr[[fx[0]]],tr[targ]);
  out=te[['Country_EN','Year',targ,fx[0]]].copy().rename(columns={targ:'actual',fx[0]:'persistence'})
  out['lasso']=mod.predict(te[fx]);out['ar1']=ar.predict(te[[fx[0]]]);out['target']=targ;out['alpha']=alp
  annual.append(out)
 post_frames.extend(annual)
post=pd.concat(post_frames,ignore_index=True)
save_csv(post,'restricted_post_period_all_predictions.csv');save_csv(pd.DataFrame(alphas),'pre2013_restricted_alpha_validation.csv')

post_summary=[];post_uncertainty=[];year_perf=[];matched=[]
for t in post_models:
 d=post[post.target==t].copy()
 for start,end in [(2013,2020),(2021,2023),(2021,2024)]:
  q=d[d.Year.between(start,end)]
  row={'target':t,'period':f'{start}-{end}','N':len(q),'countries':q.Country_EN.nunique(), 'alpha':float(q.alpha.iloc[0]),
       'RMSE_persistence':rmse(q.actual,q.persistence),'RMSE_ARX_LASSO':rmse(q.actual,q.lasso), 'RMSE_AR1':rmse(q.actual,q.ar1),'ARX_MSE_skill_pct':skill(q.actual,q.lasso,q.persistence),
       'delta_RMSE_ARX_minus_persistence':rmse(q.actual,q.lasso)-rmse(q.actual,q.persistence)}
  post_summary.append(row)
  if start>=2021: post_uncertainty.append({'target':t,'period':f'{start}-{end}',**paired_bootstrap(q)})
 for yr,q in d.groupby('Year'):
  year_perf.append({'target':t,'year':int(yr),'N':len(q),'RMSE_persistence':rmse(q.actual,q.persistence),
                    'RMSE_ARX_LASSO':rmse(q.actual,q.lasso),'MSE_skill_pct':skill(q.actual,q.lasso,q.persistence),'delta_RMSE':rmse(q.actual,q.lasso)-rmse(q.actual,q.persistence)})
 for end in [2023,2024]:
  postyears=list(range(2021,end+1))
  old=d[d.Year.between(2013,2020)];new=d[d.Year.between(2021,end)]
  # intersection countries appearing at every year in both old and newer period
  years=set(range(2013,2021))|set(postyears)
  cs=set(d.Country_EN.unique())
  for y in years:cs&=set(d.loc[d.Year==y,'Country_EN'])
  for window,subset in [('2013-2020',old),('2021-'+str(end),new)]:
   q=subset[subset.Country_EN.isin(cs)]
   matched.append({'target':t,'matched_2021_to':end,'window':window,'countries_common':len(cs),
                   'country_list':'; '.join(sorted(cs)),'N':len(q),
                   'RMSE_persistence':rmse(q.actual,q.persistence),'RMSE_ARX_LASSO':rmse(q.actual,q.lasso),
                   'ARX_MSE_skill_pct':skill(q.actual,q.lasso,q.persistence), 'delta_RMSE_ARX_minus_persistence':rmse(q.actual,q.lasso)-rmse(q.actual,q.persistence)})
save_csv(pd.DataFrame(post_summary),'restricted_period_performance.csv')
save_csv(pd.DataFrame(year_perf),'post_period_annual_performance.csv')
save_csv(pd.DataFrame(matched),'matched_country_period_comparison.csv')
with (OUT/'paired_uncertainty_intervals.json').open('w') as f:json.dump(post_uncertainty,f,indent=2)

# 6. Retrospective sequential residual-quantile 90% interval calibration (NOT distribution-free guarantee with dependence)
calibration=[];calibration_yearly=[]
# core training-year data anchored 2008 onward for fixed LASSO alpha .01
p0=[]
for year in range(2008,2021):
 tr=core[core.Year<year];te=core[core.Year==year]
 est=model(.01).fit(tr[feats],tr.HEALTH_GDP)
 arr=te[['Country_EN','Year','HEALTH_GDP']].copy().rename(columns={'HEALTH_GDP':'actual'})
 arr['forecast']=est.predict(te[feats]);p0.append(arr)
p0=pd.concat(p0,ignore_index=True)
seq=[('core_2013_2020',p0,2013,2020)]
for targ in post_models:
 fx=post_models[targ]
 d=extension.dropna(subset=[targ]+fx);d=d[d.Consecutive.astype(bool)]
 sel=float(post[post.target==targ].alpha.iloc[0]);arr=[]
 for year in range(2008,2025):
  tr=d[d.Year<year];te=d[d.Year==year]
  est=model(sel).fit(tr[fx],tr[targ]);tmp=te[['Country_EN','Year',targ]].rename(columns={targ:'actual'}).copy()
  tmp['forecast']=est.predict(te[fx]);arr.append(tmp)
 seq.append((targ+'_2021_2024',pd.concat(arr,ignore_index=True),2021,2024))
for label,data,first,last in seq:
 for yr in range(first,last+1):
  tr=data[data.Year<yr];te=data[data.Year==yr]
  e=np.abs(tr.actual.to_numpy()-tr.forecast.to_numpy())
  # empirical pooled 90th percentile; generated from prior forecast origins only, not from in-sample residuals
  q=float(np.quantile(e,.9,method='higher'))
  covers=np.abs(te.actual.to_numpy()-te.forecast.to_numpy())<=q
  calibration_yearly.append({'test':label,'Year':yr,'N':len(te),'calibration_N':len(tr),'empirical_radius_90pct':q,'nominal_coverage':.9,'coverage':float(covers.mean()),'mean_interval_width':2*q})
 vals=pd.DataFrame([r for r in calibration_yearly if r['test']==label]);weights=vals.N.to_numpy()
 calibration.append({'test':label,'N':int(weights.sum()),'nominal_coverage':.9,'pooled_empirical_coverage':float(np.average(vals.coverage,weights=weights)),'mean_interval_width':float(np.average(vals.mean_interval_width,weights=weights)),
                     'limitations':'retrospective past-origin pooled absolute residual quantiles; shared shocks and within-country dependence invalidate exact exchangeability-based coverage guarantee'})
save_csv(pd.DataFrame(calibration_yearly),'sequential_prediction_interval_annual.csv')
save_csv(pd.DataFrame(calibration),'sequential_prediction_interval_overall.csv')

# 7. File-level quality checks and metadata / country coverage
raw=pd.read_csv(ROOT/'source_dataset_762_utf8(3).csv')
ready=pd.read_csv(ROOT/'source_dataset_analysis_ready(2).csv')
comp=raw.merge(ready[['Country_EN','Year','RENEW_ENERGY']],on=['Country_EN','Year'],suffixes=('_raw','_analysis'),validate='one_to_one')
unscaled_identity=np.exp(raw.HE_PC_USD-raw.GDP_PC)*100
unit_checks={'matched_raw_to_analysis_ready_rows':len(comp),'renew_energy_10000_rescaling_max_abs_error':float(np.max(np.abs(comp.RENEW_ENERGY_raw*10000-comp.RENEW_ENERGY_analysis))),
 'raw_renew_energy_min':float(raw.RENEW_ENERGY.min()),'raw_renew_energy_max':float(raw.RENEW_ENERGY.max()),
 'ready_renew_energy_min':float(ready.RENEW_ENERGY.min()),'ready_renew_energy_max':float(ready.RENEW_ENERGY.max()),
 'ratio_reconstructed_RMSE_percentage_points':rmse(raw.HEALTH_GDP,unscaled_identity),
 'ratio_reconstructed_R2':float(1-np.sum((raw.HEALTH_GDP-unscaled_identity)**2)/np.sum((raw.HEALTH_GDP-raw.HEALTH_GDP.mean())**2)),
 'ratio_reconstructed_correlation':float(np.corrcoef(raw.HEALTH_GDP,unscaled_identity)[0,1]),
 'caveat':'The raw file has no authoritative source unit metadata; exact 10,000 transform is verified but its external validity remains unverified. Logged current-dollar unit algebra inferred from file values, not certified from missing upstream source transformations.'}
coverage=[]
for targ,fx in post_models.items():
 d=extension.dropna(subset=[targ]+fx);d=d[d.Consecutive.astype(bool)]
 for y in range(2021,2025):
  q=d[d.Year==y]
  coverage.append({'target':targ,'year':y,'countries':len(q),'country_list':'; '.join(sorted(q.Country_EN.tolist()))})
save_csv(pd.DataFrame(coverage),'extension_year_country_coverage.csv')
# output summary
report={'core':core_perf,'core_uncertainty':core_unc,'core_inference':core_infer,'sixteen_candidate_reality_check_new':rc,'training_only_MASE':mase_summary,
        'horizon_results':horizon,'lagged_expenditure_sensitivity':sens,
        'post_period_performance':post_summary,'matched_country':matched,'extension_country_coverage':coverage,'interval_calibration':calibration,
        'measurement_unit_checks':unit_checks,
        'version_notes':{'reproduced_core_method':'Lasso alpha=.01 on standardized 22 lagged features; refitted for each year t using target observations strictly earlier than t','post_method':'restricted ARX LASSO; time-ordered pre-2013 3-block squared-error tuning; alpha selected once and refitted annually; chosen alpha from supplied files','missing':'Original 4,216-row merge and source query logs; original core program available under ../core/src; per-observation data vintages and estimate flags, funding and author portal metadata are unavailable','test_nature':'original core and restricted post metrics can be reproduced numerically from supplied CSVs; new analyses are explicitly independent sensitivity checks and should not be passed off as results of legacy missing script'}}
with (OUT/'verified_analysis_summary.json').open('w') as f:json.dump(report,f,indent=2,ensure_ascii=False)
print(json.dumps({
 'core':core_perf,'core_infer':core_infer,'reality':rc,'horizon':horizon,'lagged_sensitivity':sens,'post':post_summary,
 'matched':[{'target':r['target'],'matched_2021_to':r['matched_2021_to'],'window':r['window'],'n':r['N'],'countries':r['countries_common'],'skill':r['ARX_MSE_skill_pct']} for r in matched],
 'mase':mase_summary,'calibration':calibration},indent=2,ensure_ascii=False))
