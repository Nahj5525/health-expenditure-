from pathlib import Path
import pandas as pd,numpy as np
R=Path(__file__).resolve().parent/'frontiers_new_results';post=pd.read_csv(R/'restricted_post_period_all_predictions.csv');matched=pd.read_csv(R/'matched_country_period_comparison.csv');rng=np.random.default_rng(927)
results=[]
for target in ['CHE_GDP','PUBLIC_GDP']:
 for end in (2023,2024):
  sub=matched[(matched.target==target)&(matched.matched_2021_to==end)&(matched.window==f'2021-{end}')].iloc[0]
  countries=sub.country_list.split('; ')
  p=post[(post.target==target)&(post.Year.between(2021,end))&post.Country_EN.isin(countries)].reset_index(drop=True)
  y=p.actual.to_numpy();m=p.lasso.to_numpy();b=p.persistence.to_numpy()
  delta=lambda ids:float(np.sqrt(np.mean((y[ids]-m[ids])**2))-np.sqrt(np.mean((y[ids]-b[ids])**2)))
  res={'target':target,'end_year':end,'matched_countries':len(countries),'N':len(p),'delta_RMSE':delta(np.arange(len(p)))}
  for name,blocks in [('country',{n:np.where(p.Country_EN==n)[0] for n in countries}),('year',{yr:np.where(p.Year==yr)[0] for yr in range(2021,end+1)})]:
   keys=list(blocks);vals=[]
   for i in range(5000):
    ids=np.concatenate([blocks[key] for key in rng.choice(keys,len(keys),replace=True)])
    vals.append(delta(ids))
   res[f'{name}_95CI_low'],res[f'{name}_95CI_high']=np.percentile(vals,[2.5,97.5])
  results.append(res)
a=pd.DataFrame(results);a.to_csv(R/'matched_country_paired_uncertainty.csv',index=False)
print(a.to_string(index=False))
