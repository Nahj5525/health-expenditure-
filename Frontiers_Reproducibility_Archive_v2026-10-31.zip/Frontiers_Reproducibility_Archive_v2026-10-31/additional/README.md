# Frontiers independent reviewer-requested statistical reanalysis

The new scripts reproduce one-year core LASSO (alpha=0.01) and persistence RMSE,
reconstruct the restricted post-period bridge (alpha=0.001 selected by pre-2013
validation), and generate additional reviewer-requested sensitivity tests.

## Run

Use Python 3.13 and install `pip install -r requirements.txt`. From this folder:

    python frontiers_additional_analysis.py
    python frontiers_attribution_sensitivity.py
    python matched_uncertainty.py

Outputs are written to `frontiers_new_results/`. Files already included in that
directory are numerical reference results of the analysis performed for this revision.
The run uses fixed random seeds and the supplied analytical CSVs. Minor cross-platform
floating-point differences may occur.

## Key verification

2013-2020 core: 307 forecasts, 40 countries. RMSE LASSO 0.413564720967;
RMSE persistence 0.433228919184. Corrected two-year direct: 305 cases,
RMSE 0.523003 vs 0.561760. Corrected three-year direct: 300 cases,
RMSE 0.647162 vs 0.681469.

2021-2024 restricted CHE: 141 cases, RMSE ARX 0.600983 vs persistence 0.571054.
2021-2024 government: 128 cases, RMSE ARX 0.569422 vs persistence 0.544338.

## Material unavailable

The original 4,216-row pre-filter merge and the legacy source file
`src/reproduce_analysis.py` were not provided. The original 16-candidate search
roster/predictions were also not supplied; this archive includes a clearly
labelled independent 16-candidate sensitivity instead. Dataset extraction
timestamps, historical real-time vintages, and originally selected source
indicator identifiers for IMF, ILOSTAT and V-Dem are not independently validated.
Do not label these missing parts as reproduced.

## External source metadata verified

World Bank WDI includes WHO GHED series SH.XPD.CHEX.GD.ZS,
SH.XPD.GHED.GD.ZS, SH.XPD.GHED.CH.ZS, SH.XPD.OOPC.CH.ZS and
renewable-energy series EG.FEC.RNEW.ZS. Current WDI metadata label the GHED
update as 12 December 2025, which does not prove the authors' historical
retrieval timestamp or the vintage of a specific local file.

## Description of statistical inference

- Paired country-block bootstraps sample whole national prediction paths.
- Whole-year bootstraps resample all forecast records from the same year, retaining
  a contemporaneous cross-country shock but providing few independent blocks.
- Two-way cluster variance follows V(country)+V(year)-V(intersection), small-sample
  corrections on and Student t reference with 7 degrees of freedom.
- The 16-candidate model universe is explicitly reconstructed for this new sensitivity;
  5,000 centred whole-year and whole-country bootstrap draws are provided.
- Corrected h-year forecasts require training outcomes s <= t-h and all intervening
  country-year observations to be present in the source data.
- Training MASE denominators use only consecutive historical naive changes available
  before each forecast year; one early New Zealand case lacks an eligible denominator.
- Empirical 90% forecast intervals use errors from earlier rolling forecast years only.
  They do not have formal conformal coverage guarantees with dependent panel data.

The manuscript's main statistical comparisons should be read together with
`Frontiers_Additional_Statistical_Appendix.docx`.
