"""Independent out-of-sample grouped feature ablation and conditional-on-model permutation sensitivity."""
import json
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Lasso
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'frontiers_new_results';OUT.mkdir(exist_ok=True)
d=pd.read_csv(ROOT/'analysis_dataset_one_year_ahead(3).csv');x=[c for c in d if c.startswith('L1_')]
domains={
 'health financing':['L1_PHE_CHE','L1_OOP_CHE'],
 'economy':['L1_GDP_PC','L1_GDP_DEFL','L1_PPI','L1_CPI'],
 'public finance':['L1_CA_GDP','L1_FISCAL_BAL_GDP','L1_REV_GDP','L1_EXP_GDP'],
 'social and demographic':['L1_FERT_RATE','L1_YOUTH_UNEMP','L1_UNEMP','L1_POP_LOG'],
 'political institutions':['L1_EGAL_DEM_INDEX','L1_EXPR_INFO_FREE','L1_JUSTICE_ACCESS'],
 'environment':['L1_RENEW_ENERGY','L1_WATER_PC','L1_PM25_LOG','L1_GHG_LOG'],
 'lagged outcome':['L1_HEALTH_GDP']}
assert set(x)==set(sum(domains.values(),[]))
mk=lambda:make_pipeline(StandardScaler(),Lasso(alpha=.01,max_iter=150000,random_state=0))
all_forecasts={n:[] for n in ['Full_22_features']+['Without_'+k for k in domains]};targets=[]
rng=np.random.default_rng(124)
perm_results={n:[] for n in domains}
for year in range(2013,2021):
 tr=d[d.Year<year];te=d[d.Year==year];true=te.HEALTH_GDP.to_numpy();targets.extend(true)
 full=mk().fit(tr[x],tr.HEALTH_GDP);yhat=full.predict(te[x]);all_forecasts['Full_22_features'].extend(yhat)
 base=((true-yhat)**2)
 # Grouped within-test-year permutation (same permutation for all variables in a domain)
 for domain,features in domains.items():
  for iteration in range(100):
   z=te[x].copy();ind=rng.permutation(len(te));z.loc[:,features]=te.iloc[ind][features].to_numpy()
   yp=full.predict(z)
   perm_results[domain].append({'year':year,'repeat':iteration,'mean_mse_increase':float(np.mean((true-yp)**2-base)), 'n':len(te)})
  rem=[f for f in x if f not in features]
  a=mk().fit(tr[rem],tr.HEALTH_GDP);all_forecasts['Without_'+domain].extend(a.predict(te[rem]))
rmse=lambda p:np.sqrt(np.mean((np.array(targets)-np.array(p))**2))
base=rmse(all_forecasts['Full_22_features'])
ablation=[]
for name,p in all_forecasts.items():
 ablation.append({'specification':name,'N':len(targets),'RMSE':float(rmse(p)),'RMSE_minus_full':float(rmse(p)-base)})
pd.DataFrame(ablation).to_csv(OUT/'domain_ablation_out_of_sample.csv',index=False)
permd=[]
for name,details in perm_results.items():
 p=pd.DataFrame(details)
 # weighted by yearly N but balanced 100 repeats per year
 permd.append({'domain':name,'mean_mse_increase':float(np.average(p.mean_mse_increase,weights=p.n)),'negative_repeats_share':float(np.mean(p.mean_mse_increase<0)),'permutations_per_year':100,'years':8})
pd.DataFrame(permd).to_csv(OUT/'grouped_permutation_importance.csv',index=False)
print(pd.DataFrame(ablation).to_string(index=False));print('\nPermutation:\n',pd.DataFrame(permd).to_string(index=False))
