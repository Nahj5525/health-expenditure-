from pathlib import Path
import pandas as pd, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from shutil import copy2
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures'
ORIG=ROOT/'core'/'outputs'/'figures'
for num, original in [(1,'Figure1_validation_architecture.png'),(2,'Figure2_annual_core_RMSE.png'),(5,'Figure5_SHAP_attribution.png')]:
 copy2(ORIG/original,OUT/f'Figure_{num}.png')
post=pd.read_csv(ROOT/'additional'/'frontiers_new_results'/'post_period_annual_performance.csv')
fig,axs=plt.subplots(1,2,figsize=(12.3,4.8),layout='constrained')
for ax,(key,label) in zip(axs,[('CHE_GDP','(A) Current health expenditure / GDP'),('PUBLIC_GDP','(B) Government health expenditure / GDP')]):
 d=post[(post.target==key)&post.year.between(2021,2024)].sort_values('year')
 xx=d.year.to_numpy();p=d.RMSE_persistence.to_numpy();m=d.RMSE_ARX_LASSO.to_numpy()
 ax.plot(xx,p,marker='o',linewidth=2,label='Persistence')
 ax.plot(xx,m,marker='s',linewidth=2,label='ARX-LASSO')
 ax.axvspan(2023.65,2024.35,alpha=.11,color='grey')
 ax.scatter([2024],[p[-1]],facecolors='white',edgecolors='C0',s=90,zorder=7,linewidth=1.8)
 ax.scatter([2024],[m[-1]],facecolors='white',edgecolors='C1',s=90,zorder=7,linewidth=1.8,marker='s')
 ax.set_xticks(xx);ax.set_xlim(2020.7,2024.32)
 ax.set_ylabel('RMSE (percentage points)');ax.grid(axis='y',alpha=.25)
 ax.set_title(label,fontsize=11)
 ax.text(.02,.97,'2024 coverage: '+str(int(d.iloc[-1].N))+' countries',transform=ax.transAxes,ha='left',va='top',fontsize=8.5)
 axs[0].legend(loc='best',fontsize=9)
fig.savefig(OUT/'Figure_3.png',dpi=300,bbox_inches='tight')
plt.close(fig)
bridge=pd.read_csv(ROOT/'core'/'outputs'/'tables'/'table_same_information_bridge.csv')
fig,axs=plt.subplots(1,2,figsize=(12.3,4.8),layout='constrained')
for ax,(out,label) in zip(axs,[('CHE/GDP','(A) Current health expenditure / GDP'),('Government/GDP','(B) Government health expenditure / GDP')]):
 d=bridge[bridge.Outcome==out].set_index('Window').loc[['2013-2020','2021-2024']]
 x=np.array([0,1.2]);w=.23
 for j,(col,leg) in enumerate([('Persistence_RMSE','Persistence'),('AR1_RMSE','AR(1)'),('ARX_LASSO_RMSE','ARX-LASSO')]):
  ax.bar(x+(j-1)*w,d[col].to_numpy(),width=w,label=leg)
 ax.set_xticks(x,[f'2013–2020\nN={int(d.iloc[0].N)}',f'2021–2024\nN={int(d.iloc[1].N)}'])
 ax.set_ylim(0, .77)
 ax.set_ylabel('Pooled RMSE (percentage points)');ax.set_title(label,fontsize=11)
 ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
 axs[0].legend(fontsize=9,loc='upper left')
fig.savefig(OUT/'Figure_4.png',dpi=300,bbox_inches='tight')
plt.close(fig)
from PIL import Image
for f in sorted(OUT.glob('*.png')):
 im=Image.open(f); print(f.name,im.size,im.info.get('dpi'))
