# Reproducibility archive — Frontiers in Public Health / Health Economics

Archive version: **v2026-10-31**. Source data extraction date: **2 April 2026**, as reported by the authors. The available files do not preserve the original download request/query logs or signed timestamps; the date is a statement from the authors, not an independently authenticated WHO/World Bank release-vintage record.

## Reproduce original reported results

Install requirements from `core/requirements.txt` in an isolated Python environment. Run:

    python core/run_all.py

The original core source `core/src/reproduce_analysis.py` is provided, including the country-grouped and spatiotemporal evaluation, 16-candidate model-search check and full prediction files. Expected outputs include: LASSO core RMSE **0.413565**, persistence RMSE **0.433229**, original 16-candidate country-block reality-check p = **0.5212**. This code was successfully executed after the original ZIP was supplied. The original core CSV field labeled `MASE` has been corrected to `rMAE` in this version because it divides test MAE by test-period persistence MAE; the numbers themselves have not changed.

## Reproduce independent reviewer-requested results

Using `additional/requirements.txt`, run the following from the archive root, in order:

    python additional/frontiers_additional_analysis.py
    python additional/frontiers_attribution_sensitivity.py
    python additional/matched_uncertainty.py

The additional analyses employ distinct candidate rosters and weighting/resampling assumptions. They yield a *new* 16-candidate year-block maximum-test p = **0.381** and country-block p = **0.488**. Neither test replaces the original p = 0.5212. Supporting tables and predictions are in `additional/frontiers_new_results/`; the Supplemental Statistical Verification document contains the main mappings.

## Data sources and missing stages

The core source/analysis datasets, horizon-aligned files and WHO/World Bank country extension are in `core/data/`. Indicator codebooks and the author's stated 2 April 2026 extraction date are in `core/metadata/` and `documentation/data_provenance.json`. The archive **does not include** the 4,216-row pre-filter cross-source merge, original upstream ingestion program/queries, release-vintage snapshots, or reported-versus-modelled observation flags. These upstream steps cannot be independently reconstructed from the supplied materials. The WHO/World Bank extension is retrospective and should not be called fully real-time forecasting.

## Checksums and limitations

`MANIFEST_SHA256.txt` lists SHA-256 hashes of the archive files other than the manifest. Checksums certify the content of **this local package version**, not historical download dates or an externally minted permanent DOI. A public GitHub release tag/DOI should only be cited after it exists. Funding declarations, author roles and generative-AI checkboxes must be reconciled with the live submission portal by the authors.

## Final figure reproduction

`python scripts/create_submission_figures.py` regenerates five 300-dpi PNG figures into `figures/`, including updated annual post-period and same-information panels that match the revised figure captions.
