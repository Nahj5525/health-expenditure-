from pathlib import Path
import hashlib, json, platform, sys, warnings
import numpy as np
import pandas as pd
import scipy
from scipy.stats import pearsonr, spearmanr, binomtest, t as tdist
import sklearn
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import Lasso, ElasticNet, Ridge, LinearRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_cluster_2groups
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
OUT = ROOT / 'outputs'
TAB = OUT / 'tables'; FIG = OUT / 'figures'; PRED = OUT / 'predictions'; BOOT = OUT / 'bootstrap'
for p in [TAB, FIG, PRED, BOOT]: p.mkdir(parents=True, exist_ok=True)

SEEDS = {'country_bootstrap': 0, 'shap_bootstrap': 1, 'reality_check': 2026, 'rounding': 2026, 'country_folds': 0}
ALPHA_GRID = [0.001, 0.003, 0.01, 0.03, 0.1]
warnings.filterwarnings('ignore', category=UserWarning)

CORE_FILE = DATA/'analysis'/'analysis_dataset_one_year_ahead.csv'
SOURCE_FILE = DATA/'analysis'/'source_dataset_analysis_ready.csv'
EXT_FILE = DATA/'raw'/'worldbank_latest_original_country_extension.csv'
GOV_FILE = DATA/'analysis'/'analysis_dataset_government_health_share.csv'
H2_FILE = DATA/'analysis'/'analysis_dataset_horizon_2.csv'
H3_FILE = DATA/'analysis'/'analysis_dataset_horizon_3.csv'


def rmse(y,p): return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(p))**2)))
def skill(y,p,pers):
    return float(1 - np.mean((np.asarray(y)-np.asarray(p))**2)/np.mean((np.asarray(y)-np.asarray(pers))**2))

def ordered_block_tune_lasso(df, features, target, alphas=ALPHA_GRID):
    blocks=[(2007,2008),(2009,2010),(2011,2012)]
    rows=[]
    for a in alphas:
        ys=[]; ps=[]
        for s,e in blocks:
            tr=df[df.Year<s]; va=df[df.Year.between(s,e)]
            m=Pipeline([('scale',StandardScaler()),('model',Lasso(alpha=a,max_iter=100000))])
            m.fit(tr[features],tr[target]); ys.extend(va[target]); ps.extend(m.predict(va[features]))
        rows.append({'alpha':a,'validation_RMSE':rmse(ys,ps)})
    res=pd.DataFrame(rows); return float(res.loc[res.validation_RMSE.idxmin(),'alpha']), res

def core_rolling_predictions():
    df=pd.read_csv(CORE_FILE)
    features=[c for c in df.columns if c.startswith('L1_')]
    structural=[c for c in features if c!='L1_HEALTH_GDP']
    selected_alpha,tuning=ordered_block_tune_lasso(df,features,'HEALTH_GDP')
    tuning.to_csv(OUT/'tables'/'tuning_core_lasso.csv',index=False)
    rows=[]
    for yr in range(2013,2021):
        tr=df[df.Year<yr]; te=df[df.Year==yr].copy()
        out=te[['Country_EN','Year','HEALTH_GDP','L1_HEALTH_GDP']].copy()
        out['Persistence']=te.L1_HEALTH_GDP.values
        models={
            'LASSO': Pipeline([('scale',StandardScaler()),('model',Lasso(alpha=selected_alpha,max_iter=100000))]),
            'Elastic Net': Pipeline([('scale',StandardScaler()),('model',ElasticNet(alpha=0.01,l1_ratio=0.5,max_iter=100000))]),
            'OLS': LinearRegression(),
            'SVR': Pipeline([('scale',StandardScaler()),('model',SVR(C=10,gamma=0.01,epsilon=0.01))]),
            'Gradient Boosting': GradientBoostingRegressor(n_estimators=150,learning_rate=0.1,max_depth=1,random_state=0),
        }
        for name,m in models.items():
            m.fit(tr[features],tr.HEALTH_GDP); out[name]=m.predict(te[features])
        ar=LinearRegression().fit(tr[['L1_HEALTH_GDP']],tr.HEALTH_GDP)
        out['AR(1)']=ar.predict(te[['L1_HEALTH_GDP']])
        arl=Pipeline([('scale',StandardScaler()),('model',Lasso(alpha=0.001,max_iter=100000))]).fit(tr[['L1_HEALTH_GDP']],tr.HEALTH_GDP)
        out['Penalized AR-LASSO']=arl.predict(te[['L1_HEALTH_GDP']])
        arr=Pipeline([('scale',StandardScaler()),('model',Ridge(alpha=0.001))]).fit(tr[['L1_HEALTH_GDP']],tr.HEALTH_GDP)
        out['Penalized AR-Ridge']=arr.predict(te[['L1_HEALTH_GDP']])
        # Country FE + trend Ridge
        num=features+['TIME_TREND']; xcols=num+['Country_EN']
        pre=ColumnTransformer([('num',StandardScaler(),num),('country',OneHotEncoder(handle_unknown='ignore',drop='first'),['Country_EN'])])
        fe=Pipeline([('pre',pre),('model',Ridge(alpha=10))]).fit(tr[xcols],tr.HEALTH_GDP)
        out['Country FE + trend Ridge']=fe.predict(te[xcols])
        # structural k-NN for Figure 2 and robustness
        knn=Pipeline([('scale',StandardScaler()),('model',KNeighborsRegressor(n_neighbors=5,weights='distance',p=1))]).fit(tr[structural],tr.HEALTH_GDP)
        out['Structural k-NN']=knn.predict(te[structural])
        rows.append(out)
    P=pd.concat(rows,ignore_index=True)
    P.to_csv(PRED/'core_predictions.csv',index=False)
    pers=P['Persistence']
    metrics=[]
    order=['LASSO','Elastic Net','AR(1)','Penalized AR-LASSO','OLS','Persistence','SVR','Country FE + trend Ridge','Gradient Boosting']
    for name in order:
        p=P[name]
        metrics.append({
            'Model':name,'N':len(P),'RMSE':rmse(P.HEALTH_GDP,p),'MAE':float(mean_absolute_error(P.HEALTH_GDP,p)),
            'R2':float(r2_score(P.HEALTH_GDP,p)),'MSE_skill_pct':100*skill(P.HEALTH_GDP,p,pers),
            'MASE':float(mean_absolute_error(P.HEALTH_GDP,p)/mean_absolute_error(P.HEALTH_GDP,pers))
        })
    M=pd.DataFrame(metrics); M.to_csv(TAB/'table_core_performance.csv',index=False)
    # Extended table adds the nested penalized AR-Ridge benchmark mentioned in the manuscript.
    ext_order=['LASSO','Elastic Net','AR(1)','Penalized AR-Ridge','Penalized AR-LASSO','OLS','Persistence','SVR','Country FE + trend Ridge','Gradient Boosting']
    ext=[]
    for name in ext_order:
        pp=P[name]
        ext.append({'Model':name,'N':len(P),'RMSE':rmse(P.HEALTH_GDP,pp),'MAE':float(mean_absolute_error(P.HEALTH_GDP,pp)),
                    'R2':float(r2_score(P.HEALTH_GDP,pp)),'MSE_skill_pct':100*skill(P.HEALTH_GDP,pp,pers),
                    'MASE':float(mean_absolute_error(P.HEALTH_GDP,pp)/mean_absolute_error(P.HEALTH_GDP,pers))})
    pd.DataFrame(ext).to_csv(TAB/'table_core_performance_extended.csv',index=False)
    return df,P,features,structural,selected_alpha

def transfer_protocols(df, features, structural):
    countries=np.array(sorted(df.Country_EN.unique()))
    folds=list(KFold(5,shuffle=True,random_state=SEEDS['country_folds']).split(countries))
    rows=[]
    for _,testidx in folds:
        test=set(countries[testidx])
        # retrospective grouped
        tr=df[~df.Country_EN.isin(test)]; te=df[df.Country_EN.isin(test)]
        m=Pipeline([('scale',StandardScaler()),('model',Lasso(alpha=0.01,max_iter=100000))]).fit(tr[features],tr.HEALTH_GDP)
        for i,r in te.reset_index(drop=True).iterrows():
            rows.append({'Protocol':'Retrospective grouped','Country_EN':r.Country_EN,'Year':r.Year,'y':r.HEALTH_GDP,'model':float(m.predict(pd.DataFrame([r[features].values],columns=features))[0]),'persistence':r.L1_HEALTH_GDP,'ar':np.nan})
        # spatiotemporal
        for yr in range(2013,2021):
            tr=df[(df.Year<yr)&(~df.Country_EN.isin(test))]; te=df[(df.Year==yr)&(df.Country_EN.isin(test))]
            if te.empty: continue
            m=Pipeline([('scale',StandardScaler()),('model',Lasso(alpha=0.01,max_iter=100000))]).fit(tr[features],tr.HEALTH_GDP)
            ar=LinearRegression().fit(tr[['L1_HEALTH_GDP']],tr.HEALTH_GDP)
            pp=m.predict(te[features]); pa=ar.predict(te[['L1_HEALTH_GDP']])
            for j,(_,r) in enumerate(te.iterrows()):
                rows.append({'Protocol':'Spatiotemporal holdout','Country_EN':r.Country_EN,'Year':r.Year,'y':r.HEALTH_GDP,'model':pp[j],'persistence':r.L1_HEALTH_GDP,'ar':pa[j]})
    T=pd.DataFrame(rows);T.to_csv(PRED/'transfer_predictions.csv',index=False)
    report=[]
    for prot in ['Spatiotemporal holdout','Retrospective grouped']:
        d=T[T.Protocol==prot]
        report.append({'Protocol':prot,'Model':'Dynamic LASSO','N':len(d),'RMSE':rmse(d.y,d.model),'MSE_skill_pct':100*skill(d.y,d.model,d.persistence)})
        if prot=='Spatiotemporal holdout':
            report.append({'Protocol':prot,'Model':'AR(1)','N':len(d),'RMSE':rmse(d.y,d.ar),'MSE_skill_pct':100*skill(d.y,d.ar,d.persistence)})
            report.append({'Protocol':prot,'Model':'Persistence','N':len(d),'RMSE':rmse(d.y,d.persistence),'MSE_skill_pct':0.0})
    # structural kNN rolling
    ys=[];ps=[];pers=[]
    for yr in range(2013,2021):
        tr=df[df.Year<yr];te=df[df.Year==yr]
        m=Pipeline([('scale',StandardScaler()),('model',KNeighborsRegressor(n_neighbors=5,weights='distance',p=1))]).fit(tr[structural],tr.HEALTH_GDP)
        ys.extend(te.HEALTH_GDP);ps.extend(m.predict(te[structural]));pers.extend(te.L1_HEALTH_GDP)
    report.append({'Protocol':'Primary rolling','Model':'Structural k-NN','N':len(ys),'RMSE':rmse(ys,ps),'MSE_skill_pct':100*skill(ys,ps,pers)})
    # Structural OLS is reported as a secondary comparator in the manuscript text.
    ys=[];ps=[];pers=[]
    for yr in range(2013,2021):
        tr=df[df.Year<yr];te=df[df.Year==yr]
        m=LinearRegression().fit(tr[structural],tr.HEALTH_GDP)
        ys.extend(te.HEALTH_GDP);ps.extend(m.predict(te[structural]));pers.extend(te.L1_HEALTH_GDP)
    report.append({'Protocol':'Primary rolling','Model':'Structural OLS','N':len(ys),'RMSE':rmse(ys,ps),'MSE_skill_pct':100*skill(ys,ps,pers)})
    R=pd.DataFrame(report);R.to_csv(TAB/'table_validation_protocols.csv',index=False);return R

def country_bootstrap_delta(P, a, b, B=5000, seed=0):
    # Vectorized country-cluster bootstrap: resample country-level SSE/count
    # summaries rather than repeatedly concatenating row-level DataFrames.
    g = P.assign(
        sse_a=(P.HEALTH_GDP-P[a])**2,
        sse_b=(P.HEALTH_GDP-P[b])**2
    ).groupby('Country_EN').agg(n=('HEALTH_GDP','size'), sse_a=('sse_a','sum'), sse_b=('sse_b','sum'))
    arr = g[['n','sse_a','sse_b']].to_numpy(float)
    rng=np.random.default_rng(seed)
    idx=rng.integers(0,len(arr),size=(B,len(arr)))
    draws=arr[idx].sum(axis=1)
    return np.sqrt(draws[:,1]/draws[:,0])-np.sqrt(draws[:,2]/draws[:,0])

def two_way_loss_p(P,a,b):
    # positive loss differential means model a improves over b
    d=(P.HEALTH_GDP-P[b])**2-(P.HEALTH_GDP-P[a])**2
    fit=sm.OLS(d,np.ones((len(d),1))).fit()
    cov=cov_cluster_2groups(fit,pd.Categorical(P.Country_EN).codes,P.Year)[0]
    se=float(np.sqrt(cov[0,0])); stat=float(fit.params.iloc[0]/se)
    return float(2*(1-tdist.cdf(abs(stat),7)))

def reality_check(P):
    df=pd.read_csv(CORE_FILE);F=[c for c in df if c.startswith('L1_')]
    # 16 frozen dynamic candidate specifications; all choices fixed before 2013-2020 evaluation.
    rows=[]
    for yr in range(2013,2021):
        tr=df[df.Year<yr];te=df[df.Year==yr].copy();out=te[['Country_EN','Year','HEALTH_GDP','L1_HEALTH_GDP']].copy();out['Persistence']=te.L1_HEALTH_GDP.values
        specs={
          'LASSO_a0.01':Pipeline([('s',StandardScaler()),('m',Lasso(alpha=.01,max_iter=100000))]),
          'ElasticNet_a0.01':Pipeline([('s',StandardScaler()),('m',ElasticNet(alpha=.01,l1_ratio=.5,max_iter=100000))]),
          'OLS':LinearRegression(),
          'Ridge_a10':Pipeline([('s',StandardScaler()),('m',Ridge(alpha=10))]),
          'SVR':Pipeline([('s',StandardScaler()),('m',SVR(C=10,gamma=.01,epsilon=.01))]),
          'GB_tuned':GradientBoostingRegressor(n_estimators=150,learning_rate=.1,max_depth=1,random_state=0),
          'RF':RandomForestRegressor(n_estimators=300,min_samples_leaf=3,max_features=.7,random_state=0,n_jobs=-1),
          'GB_conservative':GradientBoostingRegressor(n_estimators=100,max_depth=2,learning_rate=.03,random_state=0),
          'XGBoost':XGBRegressor(n_estimators=200,max_depth=2,learning_rate=.03,subsample=.8,colsample_bytree=.8,reg_lambda=5,objective='reg:squarederror',random_state=0,n_jobs=2),
          'LightGBM':LGBMRegressor(n_estimators=150,num_leaves=7,learning_rate=.03,min_child_samples=20,reg_lambda=5,verbosity=-1,random_state=0,n_jobs=2),
          'LASSO_a0.005':Pipeline([('s',StandardScaler()),('m',Lasso(alpha=.005,max_iter=100000))]),
          'LASSO_a0.02':Pipeline([('s',StandardScaler()),('m',Lasso(alpha=.02,max_iter=100000))]),
          'ElasticNet_a0.005':Pipeline([('s',StandardScaler()),('m',ElasticNet(alpha=.005,l1_ratio=.5,max_iter=100000))]),
          'ElasticNet_a0.02':Pipeline([('s',StandardScaler()),('m',ElasticNet(alpha=.02,l1_ratio=.5,max_iter=100000))]),
        }
        for n,m in specs.items():m.fit(tr[F],tr.HEALTH_GDP);out[n]=m.predict(te[F])
        ar=LinearRegression().fit(tr[['L1_HEALTH_GDP']],tr.HEALTH_GDP);out['AR1']=ar.predict(te[['L1_HEALTH_GDP']])
        arl=Pipeline([('s',StandardScaler()),('m',Lasso(alpha=.001,max_iter=100000))]).fit(tr[['L1_HEALTH_GDP']],tr.HEALTH_GDP);out['AR_LASSO']=arl.predict(te[['L1_HEALTH_GDP']])
        rows.append(out)
    Q=pd.concat(rows,ignore_index=True);Q.to_csv(PRED/'reality_check_candidate_predictions.csv',index=False)
    mods=[c for c in Q.columns if c not in ['Country_EN','Year','HEALTH_GDP','L1_HEALTH_GDP','Persistence']]
    dif=pd.DataFrame({m:(Q.HEALTH_GDP-Q.Persistence)**2-(Q.HEALTH_GDP-Q[m])**2 for m in mods});dif['Country_EN']=Q.Country_EN
    C=dif.groupby('Country_EN')[mods].mean(); obs=np.sqrt(len(C))*C.mean().max(); mean=C.mean().to_numpy(); A=C.to_numpy();rng=np.random.default_rng(SEEDS['reality_check']); draws=[]
    for _ in range(5000):
        idx=rng.integers(0,len(C),len(C)); draws.append(np.sqrt(len(C))*np.max(A[idx].mean(0)-mean))
    draws=np.array(draws);pd.DataFrame({'bootstrap_max_centered_stat':draws}).to_csv(BOOT/'reality_check_draws.csv',index=False)
    return float((draws>=obs).mean()), C.mean().idxmax()

def uncertainty(P):
    comparisons=[('LASSO','Persistence'),('LASSO','Penalized AR-LASSO'),('LASSO','AR(1)'),('LASSO','Country FE + trend Ridge')]
    rows=[]
    for a,b in comparisons:
        vals=country_bootstrap_delta(P,a,b,5000,SEEDS['country_bootstrap'])
        pd.DataFrame({'delta_RMSE':vals}).to_csv(BOOT/f'bootstrap_{a.replace(" ","_").replace("/","")}_vs_{b.replace(" ","_").replace("/","")}.csv',index=False)
        wins=sum(rmse(g.HEALTH_GDP,g[a])<rmse(g.HEALTH_GDP,g[b]) for _,g in P.groupby('Country_EN'))
        rows.append({'Comparison':f'{a} vs {b}','Delta_RMSE':rmse(P.HEALTH_GDP,P[a])-rmse(P.HEALTH_GDP,P[b]),'CI_low':float(np.quantile(vals,.025)),'CI_high':float(np.quantile(vals,.975)),'two_way_p':two_way_loss_p(P,a,b),'country_wins':wins})
    p_rc,winner=reality_check(P)
    # coherent source-level rounding perturbation
    src=pd.read_csv(SOURCE_FILE)[['Country_EN','Year','HEALTH_GDP']]
    df=pd.read_csv(CORE_FILE); structural=[c for c in df if c.startswith('L1_') and c!='L1_HEALTH_GDP']
    keys=list(zip(src.Country_EN,src.Year));ki={k:i for i,k in enumerate(keys)}; tidx=np.array([ki[(c,y)] for c,y in zip(df.Country_EN,df.Year)]);lidx=np.array([ki[(c,y-1)] for c,y in zip(df.Country_EN,df.Year)])
    Xs=df[structural].to_numpy();years=df.Year.to_numpy();yb=df.HEALTH_GDP.to_numpy();lb=df.L1_HEALTH_GDP.to_numpy();rng=np.random.default_rng(SEEDS['rounding']);rvals=[]
    for _ in range(1000):
        u=rng.uniform(-.05,.05,len(src));yp=yb+u[tidx];lp=lb+u[lidx];pred=np.full(len(df),np.nan)
        for yr in range(2013,2021):
            tr=years<yr;te=years==yr;Xtr=np.column_stack([Xs[tr],lp[tr]]);Xte=np.column_stack([Xs[te],lp[te]])
            m=Pipeline([('s',StandardScaler()),('m',Lasso(alpha=.01,max_iter=100000))]).fit(Xtr,yp[tr]);pred[te]=m.predict(Xte)
        ev=years>=2013;rvals.append(rmse(yp[ev],pred[ev])-rmse(yp[ev],lp[ev]))
    pd.DataFrame({'delta_RMSE':rvals}).to_csv(BOOT/'rounding_perturbation_draws.csv',index=False)
    U=pd.DataFrame(rows);U.to_csv(TAB/'table_uncertainty.csv',index=False)
    summary={'reality_check_p':p_rc,'reality_check_winner':winner,'rounding_median':float(np.median(rvals)),'rounding_ci':[float(x) for x in np.quantile(rvals,[.025,.975])],'rounding_p_better':float(np.mean(np.array(rvals)<0))}
    (OUT/'uncertainty_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    return U,summary

def postperiod_bridge():
    ext=pd.read_csv(EXT_FILE);ext=ext[ext.Consecutive==True].copy()
    configs=[('CHE/GDP','CHE_GDP',['L1_CHE_GDP','L1_PUBLIC_CHE','L1_OOP_CHE'],'L1_CHE_GDP'),('Government/GDP','PUBLIC_GDP',['L1_PUBLIC_GDP','L1_OOP_CHE'],'L1_PUBLIC_GDP')]
    prows=[]
    for label,target,feats,lag in configs:
        rows=[]
        for yr in range(2013,2025):
            tr=ext[ext.Year<yr].dropna(subset=[target]+feats+[lag]);te=ext[ext.Year==yr].dropna(subset=[target]+feats+[lag])
            if te.empty:continue
            las=Pipeline([('s',StandardScaler()),('m',Lasso(alpha=.001,max_iter=100000))]).fit(tr[feats],tr[target]);ar=LinearRegression().fit(tr[[lag]],tr[target])
            tmp=te[['Country_EN','Year',target,lag]].copy();tmp=tmp.rename(columns={target:'y',lag:'Persistence'});tmp['ARX-LASSO']=las.predict(te[feats]);tmp['AR(1)']=ar.predict(te[[lag]]);tmp['Outcome']=label;rows.append(tmp)
        Q=pd.concat(rows,ignore_index=True);prows.append(Q)
    P=pd.concat(prows,ignore_index=True);P.to_csv(PRED/'postperiod_bridge_predictions.csv',index=False)
    # detailed postperiod
    rows=[]
    for outcome in ['CHE/GDP','Government/GDP']:
        d=P[(P.Outcome==outcome)&(P.Year>=2021)]
        for end in [2023,2024]:
            s=d[d.Year<=end]
            rows.append({'Outcome':outcome,'Window':f'2021-{end}','N':len(s),'Persistence_RMSE':rmse(s.y,s.Persistence),'ARX_LASSO_RMSE':rmse(s.y,s['ARX-LASSO']),'AR1_RMSE':rmse(s.y,s['AR(1)']),'ARX_skill_pct':100*skill(s.y,s['ARX-LASSO'],s.Persistence)})
    pd.DataFrame(rows).to_csv(TAB/'table_postperiod.csv',index=False)
    # same-information bridge
    rows=[]
    for outcome in ['CHE/GDP','Government/GDP']:
        d=P[P.Outcome==outcome]
        for start,end in [(2013,2020),(2021,2024)]:
            s=d[d.Year.between(start,end)]
            rows.append({'Outcome':outcome,'Window':f'{start}-{end}','N':len(s),'Persistence_RMSE':rmse(s.y,s.Persistence),'AR1_RMSE':rmse(s.y,s['AR(1)']),'ARX_LASSO_RMSE':rmse(s.y,s['ARX-LASSO']),'ARX_skill_pct':100*skill(s.y,s['ARX-LASSO'],s.Persistence)})
    pd.DataFrame(rows).to_csv(TAB/'table_same_information_bridge.csv',index=False)
    return P

def robustness(core_df, core_P):
    rows=[]
    # horizon 1/2/3 with shared compact grid
    for h,file in [(1,CORE_FILE),(2,H2_FILE),(3,H3_FILE)]:
        d=pd.read_csv(file);feats=[c for c in d if c.startswith(f'L{h}_')];lag=f'L{h}_HEALTH_GDP';a,_=ordered_block_tune_lasso(d,feats,'HEALTH_GDP')
        y=[];p=[];pers=[]
        for yr in range(2013,2021):
            tr=d[d.Year<yr];te=d[d.Year==yr]
            if te.empty:continue
            m=Pipeline([('s',StandardScaler()),('m',Lasso(alpha=a,max_iter=100000))]).fit(tr[feats],tr.HEALTH_GDP);y.extend(te.HEALTH_GDP);p.extend(m.predict(te[feats]));pers.extend(te[lag])
        rows.append({'Target_or_restriction':f'{h}-year CHE/GDP','N':len(y),'LASSO_RMSE':rmse(y,p),'Persistence_RMSE':rmse(y,pers),'LASSO_skill_pct':100*skill(y,p,pers),'selected_alpha':a})
    # derived government
    d=pd.read_csv(GOV_FILE);feats=[c for c in d if c.startswith('L1_')];a,_=ordered_block_tune_lasso(d,feats,'GGHE_GDP');y=[];p=[];pers=[]
    for yr in range(2013,2021):
        tr=d[d.Year<yr];te=d[d.Year==yr];m=Pipeline([('s',StandardScaler()),('m',Lasso(alpha=a,max_iter=100000))]).fit(tr[feats],tr.GGHE_GDP);y.extend(te.GGHE_GDP);p.extend(m.predict(te[feats]));pers.extend(te.L1_GGHE_GDP)
    rows.append({'Target_or_restriction':'1-year derived government/GDP','N':len(y),'LASSO_RMSE':rmse(y,p),'Persistence_RMSE':rmse(y,pers),'LASSO_skill_pct':100*skill(y,p,pers),'selected_alpha':a})
    # pre-pandemic from core predictions
    s=core_P[core_P.Year<=2019];rows.append({'Target_or_restriction':'1-year CHE/GDP, 2013-2019','N':len(s),'LASSO_RMSE':rmse(s.HEALTH_GDP,s.LASSO),'Persistence_RMSE':rmse(s.HEALTH_GDP,s.Persistence),'LASSO_skill_pct':100*skill(s.HEALTH_GDP,s.LASSO,s.Persistence),'selected_alpha':0.01})
    # >= 15 histories, refit within restricted sample
    counts=core_df.groupby('Country_EN').size();keep=counts[counts>=15].index;d=core_df[core_df.Country_EN.isin(keep)];feats=[c for c in d if c.startswith('L1_')];y=[];p=[];pers=[]
    for yr in range(2013,2021):
        tr=d[d.Year<yr];te=d[d.Year==yr];m=Pipeline([('s',StandardScaler()),('m',Lasso(alpha=.01,max_iter=100000))]).fit(tr[feats],tr.HEALTH_GDP);y.extend(te.HEALTH_GDP);p.extend(m.predict(te[feats]));pers.extend(te.L1_HEALTH_GDP)
    rows.append({'Target_or_restriction':'1-year CHE/GDP, >=15 histories','N':len(y),'LASSO_RMSE':rmse(y,p),'Persistence_RMSE':rmse(y,pers),'LASSO_skill_pct':100*skill(y,p,pers),'selected_alpha':0.01})
    R=pd.DataFrame(rows);R.to_csv(TAB/'table_robustness.csv',index=False);return R

def shap_analysis(core_df):
    feats=[c for c in core_df if c.startswith('L1_')];rows=[];sel={f:0 for f in feats}
    for yr in range(2013,2021):
        tr=core_df[core_df.Year<yr];te=core_df[core_df.Year==yr];sc=StandardScaler().fit(tr[feats]);Xtr=sc.transform(tr[feats]);Xte=sc.transform(te[feats]);m=Lasso(alpha=.01,max_iter=100000).fit(Xtr,tr.HEALTH_GDP);sh=Xte*m.coef_
        for f,c in zip(feats,m.coef_):sel[f]+=int(abs(c)>1e-14)
        tmp=pd.DataFrame(sh,columns=feats);tmp['Country_EN']=te.Country_EN.values;tmp['Year']=yr;rows.append(tmp)
    S=pd.concat(rows,ignore_index=True);S.to_csv(PRED/'rolling_shap_values.csv',index=False)
    ma=S[feats].abs().mean();signed=S[feats].mean();total=ma.sum()
    # Vectorized country-block bootstrap for mean absolute SHAP values.
    absS=S[feats].abs().copy(); absS['Country_EN']=S.Country_EN.values
    sums=absS.groupby('Country_EN')[feats].sum(); counts=absS.groupby('Country_EN').size()
    countries=sums.index; A=sums.to_numpy(float); n=counts.reindex(countries).to_numpy(float)
    rng=np.random.default_rng(SEEDS['shap_bootstrap']); B=5000
    idx=rng.integers(0,len(countries),size=(B,len(countries)))
    draw_sums=A[idx].sum(axis=1); draw_n=n[idx].sum(axis=1)[:,None]
    draw_means=draw_sums/draw_n
    qlo=np.quantile(draw_means,.025,axis=0); qhi=np.quantile(draw_means,.975,axis=0)
    rows=[]
    for j,f in enumerate(feats):
        rows.append({'Predictor':f,'Mean_abs_SHAP':ma[f],'Signed_mean_SHAP':signed[f],'CI_low':qlo[j],'CI_high':qhi[j],'Share_pct':100*ma[f]/total,'Selected_origins':sel[f]})
    R=pd.DataFrame(rows).sort_values('Mean_abs_SHAP',ascending=False);R.to_csv(TAB/'table_shap_full.csv',index=False);return R

def data_audit_and_denominator():
    src=pd.read_csv(SOURCE_FILE)
    recon=np.exp(src.HE_PC_USD-src.GDP_PC)*100
    aud={'reconstruction_RMSE':rmse(src.HEALTH_GDP,recon),'reconstruction_corr':float(np.corrcoef(src.HEALTH_GDP,recon)[0,1]),'reconstruction_R2':float(r2_score(src.HEALTH_GDP,recon)),'health_gdp_mean':float(src.HEALTH_GDP.mean()),'health_gdp_sd':float(src.HEALTH_GDP.std(ddof=1)),'phe_che_mean':float(src.PHE_CHE.mean()),'oop_che_mean':float(src.OOP_CHE.mean()),'gghe_gdp_mean':float(src.GGHE_GDP.mean())}
    # denominator correlations
    d=src.sort_values(['Country_EN','Year']).copy();d['LOG_NOM_GDP']=d.GDP_PC+d.POP_LOG;d['lag_year']=d.groupby('Country_EN').Year.shift(1);d['dCHE']=d.HEALTH_GDP-d.groupby('Country_EN').HEALTH_GDP.shift(1);d['dGDP']=d.LOG_NOM_GDP-d.groupby('Country_EN').LOG_NOM_GDP.shift(1);d['consecutive']=(d.Year-d.lag_year)==1
    out={}
    for lab,mask in [('2013_2019',d.Year.between(2013,2019)&d.consecutive),('2020',(d.Year==2020)&d.consecutive)]:
        z=d[mask].dropna(subset=['dCHE','dGDP']);pr=pearsonr(z.dCHE,z.dGDP);sr=spearmanr(z.dCHE,z.dGDP);out[lab]={'N':len(z),'pearson_r':float(pr.statistic),'pearson_p':float(pr.pvalue),'spearman_rho':float(sr.statistic),'spearman_p':float(sr.pvalue)}
    # error correlations in 2013-2020
    P=pd.read_csv(PRED/'core_predictions.csv');chg=d[d.Year.between(2013,2020)&d.consecutive][['Country_EN','Year','dGDP']];m=P.merge(chg,on=['Country_EN','Year'],how='left');
    for model in ['Persistence','AR(1)','LASSO']:
        pr=pearsonr(abs(m.dGDP),abs(m.HEALTH_GDP-m[model]));out[f'absGDP_vs_absError_{model}']={'pearson_r':float(pr.statistic),'p':float(pr.pvalue)}
    (OUT/'data_audit.json').write_text(json.dumps(aud,indent=2),encoding='utf-8');(OUT/'denominator_diagnostic.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    return aud,out

def make_figures(P, postP, shap):
    # Figure 1 architecture
    fig,ax=plt.subplots(figsize=(9,5.2));ax.set_xlim(0,10);ax.set_ylim(0,6);ax.axis('off')
    boxes=[(0.6,4.5,2.3,0.8,'Source panel','762 country-years\n41 countries'),(3.8,4.5,2.3,0.8,'Reference-year alignment','709 one-year pairs\n40 countries'),(7.0,4.5,2.3,0.8,'Information sets','structural and\ndynamic predictors'),(1.2,2.5,2.7,0.9,'Temporal protocol','pre-2013 tuning; 2013-2020\nexpanding-window evaluation'),(6.1,2.5,2.7,0.9,'Transfer protocols','retrospective grouped CV and\nspatiotemporal holdout'),(3.5,0.55,3.3,0.9,'Dependence-aware assessment','country-block bootstrap; two-way clustered loss;\nreality check; rounding and domain tests')]
    for x,y,w,h,title,sub in boxes:
        p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.08',fill=False,linewidth=1.4);ax.add_patch(p);ax.text(x+w/2,y+h*.64,title,ha='center',va='center',weight='bold',fontsize=10);ax.text(x+w/2,y+h*.27,sub,ha='center',va='center',fontsize=8)
    for a,b in [((2.9,4.9),(3.8,4.9)),((6.1,4.9),(7,4.9)),((4.9,4.5),(2.55,3.4)),((8.1,4.5),(7.45,3.4)),((2.55,2.5),(4.6,1.45)),((7.45,2.5),(5.6,1.45))]: ax.add_patch(FancyArrowPatch(a,b,arrowstyle='->',mutation_scale=10,linewidth=1.2))
    fig.tight_layout();fig.savefig(FIG/'Figure1_validation_architecture.png',dpi=300,bbox_inches='tight');plt.close(fig)
    # Figure 2 annual RMSE
    annual=[]
    for yr,g in P.groupby('Year'):
        for model in ['Structural k-NN','AR(1)','LASSO','Persistence']:annual.append({'Year':yr,'Model':model,'RMSE':rmse(g.HEALTH_GDP,g[model])})
    A=pd.DataFrame(annual);fig,ax=plt.subplots(figsize=(7.5,4.6))
    for model,g in A.groupby('Model'):ax.plot(g.Year,g.RMSE,marker='o',label=model)
    ax.set_xlabel('Forecast year');ax.set_ylabel('RMSE (percentage points)');ax.legend(frameon=False,ncol=2);ax.grid(alpha=.2);fig.tight_layout();fig.savefig(FIG/'Figure2_annual_core_RMSE.png',dpi=300);plt.close(fig)
    # Figures 3-4: post-period RMSE, one outcome per figure.
    for num,outcome,title,stem in [
        (3,'CHE/GDP','Current health expenditure/GDP','Figure3_postperiod_CHE_RMSE.png'),
        (4,'Government/GDP','Government health expenditure/GDP','Figure4_postperiod_government_RMSE.png')]:
        d=postP[(postP.Outcome==outcome)&(postP.Year>=2021)]
        fig,ax=plt.subplots(figsize=(7.5,4.6))
        for model in ['Persistence','AR(1)','ARX-LASSO']:
            vals=[{'Year':yr,'RMSE':rmse(g.y,g[model])} for yr,g in d.groupby('Year')];v=pd.DataFrame(vals)
            ax.plot(v.Year,v.RMSE,marker='o',label=model)
        ax.set_title(title);ax.set_xlabel('Forecast year');ax.set_ylabel('RMSE (percentage points)')
        ax.set_xticks(sorted(d.Year.unique()));ax.legend(frameon=False);ax.grid(alpha=.2)
        fig.tight_layout();fig.savefig(FIG/stem,dpi=300);plt.close(fig)
    # Figure 5 SHAP
    top=shap.head(10).iloc[::-1];labels={'L1_HEALTH_GDP':'Lagged health expenditure share','L1_EXPR_INFO_FREE':'Freedom of expression/information','L1_YOUTH_UNEMP':'Youth unemployment','L1_GHG_LOG':'ln GHG emissions','L1_UNEMP':'Total unemployment','L1_PHE_CHE':'Public financing share','L1_POP_LOG':'ln population','L1_CA_GDP':'Current-account balance','L1_FISCAL_BAL_GDP':'Fiscal balance','L1_JUSTICE_ACCESS':'Access to justice'}
    fig,ax=plt.subplots(figsize=(8,5));x=top.Mean_abs_SHAP.to_numpy();lo=x-top.CI_low.to_numpy();hi=top.CI_high.to_numpy()-x;ax.barh(range(len(top)),x,xerr=np.vstack([lo,hi]),capsize=3);ax.set_yticks(range(len(top)),[labels.get(v,v) for v in top.Predictor]);ax.set_xscale('log');ax.set_xlabel('Mean absolute SHAP value (percentage points; log scale)');ax.grid(axis='x',alpha=.2);fig.tight_layout();fig.savefig(FIG/'Figure5_SHAP_attribution.png',dpi=300);plt.close(fig)

def write_environment():
    env={'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'scikit-learn':sklearn.__version__,'statsmodels':sm.__version__}
    (ROOT/'metadata'/'environment.json').write_text(json.dumps(env,indent=2),encoding='utf-8')

def main():
    df,P,features,structural,a=core_rolling_predictions();transfer_protocols(df,features,structural);U,us=uncertainty(P);postP=postperiod_bridge();R=robustness(df,P);S=shap_analysis(df);audit,den=data_audit_and_denominator();make_figures(P,postP,S);write_environment()
    summary={'core_alpha':a,'core_lasso_rmse':rmse(P.HEALTH_GDP,P.LASSO),'persistence_rmse':rmse(P.HEALTH_GDP,P.Persistence),'ar1_rmse':rmse(P.HEALTH_GDP,P['AR(1)']),'reality_check_p':us['reality_check_p'],'rounding_median':us['rounding_median'],'shap_lag_share_pct':float(S.iloc[0].Share_pct)}
    (OUT/'headline_results.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
