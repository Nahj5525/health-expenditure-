# Frontiers in Public Health – Health Economics reproducibility package

This archive accompanies the manuscript **Persistence remains a robust benchmark for forecasting national health-expenditure shares: sparse machine-learning evidence from 41 countries**.

Target: **Frontiers in Public Health – Health Economics**, article type **Original Research**.

## Quick start

1. Create a Python environment (Python 3.13 was used for the archived run).
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `python run_all.py`

The script rebuilds the headline tables, observation-level forecasts, bootstrap diagnostics, SHAP summaries, post-period tests, robustness analyses, and manuscript figures under `outputs/`. On the archived environment, a complete run takes approximately 20–30 seconds.

## Expected headline results

A successful run prints a JSON summary. Expected values (minor platform-level floating-point differences may occur) are:

- core LASSO alpha: 0.01
- core LASSO RMSE: 0.413565
- persistence RMSE: 0.433229
- AR(1) RMSE: 0.421676
- 16-candidate model-search reality-check p-value: 0.5212
- rounding-resolution median LASSO-minus-persistence RMSE difference: -0.019519
- lagged health-expenditure-share contribution to mean absolute SHAP: 91.094%

## Data organization

- `data/raw/`: supplied WHO/World Bank/current-release source and extension files.
- `data/analysis/`: cleaned complete-case and horizon-aligned analytical files.
- `metadata/variable_codebook.csv`: variable definitions, sources, and analysis roles.
- `metadata/manuscript_results_map.csv`: map from manuscript claims to reproducibility outputs.
- `metadata/seeds_and_protocols.json`: fixed seeds and evaluation/tuning protocols.
- `metadata/environment.json`: recorded software environment.
- `metadata/checksums_sha256.txt`: SHA-256 hashes of archived files (excluding the checksum file itself).

The unavailable 4,216-row pre-filter merge referenced in the manuscript is **not** represented as reproducible. The archive starts from the supplied 762-row complete-case panel and official-source extension files, matching the limitation stated in the manuscript.

## Reproducibility design

- All forecast inputs are reference-year lagged.
- The primary evaluation uses expanding forecast origins from 2013 through 2020.
- Country transfer uses five folds with seed 0.
- Country-block bootstrap uses seed 0; the model-search reality check uses seed 2026; the rounding-resolution simulation uses seed 2026.
- Hyperparameter choices are frozen before evaluation; core LASSO tuning uses ordered validation blocks ending in 2012 and the alpha grid `[0.001, 0.003, 0.01, 0.03, 0.1]`.

## Main output files

- `outputs/tables/table_core_performance.csv`
- `outputs/tables/table_core_performance_extended.csv`
- `outputs/tables/table_validation_protocols.csv`
- `outputs/tables/table_uncertainty.csv`
- `outputs/tables/table_postperiod.csv`
- `outputs/tables/table_same_information_bridge.csv`
- `outputs/tables/table_robustness.csv`
- `outputs/tables/table_shap_full.csv`
- `outputs/predictions/`: forecast- and SHAP-level outputs
- `outputs/bootstrap/`: bootstrap, reality-check, and rounding-simulation draws
- `outputs/figures/`: manuscript figures
- `Supplementary_Material_1_Supplementary_Appendix.docx`: supplementary reproducibility tables and file map

## Software disclosure

OpenAI ChatGPT (GPT-5.6 Sol) was used to support language editing, structural organization, document formatting, and reproducibility-oriented code review. It was not used to create or alter source observations. The archived analyses were executed in the recorded environment; the authors retain responsibility for the data, numerical results, interpretation, and manuscript text.
